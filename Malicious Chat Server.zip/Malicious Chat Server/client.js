// client.js
const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto"); //added for hashing

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let username = "";

//helper to compute hash
function sha256hex(text) {
  return crypto.createHash("sha256").update(text, "utf8").digest("hex");
}

const SIG_DELIM = "||SIG:"; //used to attach signature to the message

socket.on("connect", () => {
  console.log("Connected to the server");

  rl.question("Enter your username: ", (input) => {
    username = input;
    console.log(`Welcome, ${username} to the chat`);
    rl.prompt();

    rl.on("line", (message) => {
      if (message.trim()) {
        //compute hash and attach signature to the message payload
        const hash = sha256hex(message);
        const payloadMessage = message + SIG_DELIM + hash;
        socket.emit("message", { username, message: payloadMessage });
      }
      rl.prompt();
    });
  });
});

//verify signature and warn if mismatch
socket.on("message", (data) => {
  const { username: senderUsername, message: senderMessage } = data;

  if (senderUsername === username) {
    return;
  }

  const delimIndex = senderMessage.indexOf(SIG_DELIM);

  if (delimIndex === -1) {
    console.log(
      `${senderUsername}: ${senderMessage} \n[WARNING] message may have been changed during transmission.`
    );
    rl.prompt();
    return;
  }

  const originalPart = senderMessage.slice(0, delimIndex);
  const receivedSig = senderMessage.slice(delimIndex + SIG_DELIM.length);
  const computedHash = sha256hex(originalPart);

  if (receivedSig === computedHash) {
    console.log(`${senderUsername}: ${originalPart}`);
  } else {
    console.log(`${senderUsername}: ${originalPart}`);
    console.log(
      `[WARNING] message may have been changed during transmission.`
    );
  }
  rl.prompt();
});

socket.on("disconnect", () => {
  console.log("Server disconnected, Exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});