const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");
const socket = io("http://localhost:3000");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let username = "";
let targetUsername = "";
const users = new Map();
let keyPair;

function encodeKey(key) {
  return Buffer.from(key).toString("base64");
}

function decodeKey(encoded) {
  return Buffer.from(encoded, "base64").toString("utf8");
}

function generateRSAKeys() {
  keyPair = crypto.generateKeyPairSync("rsa", {
    modulusLength: 2048,
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
  });
}

function encryptMessage(publicKey, message) {
  return crypto
    .publicEncrypt(
      {
        key: publicKey,
        padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
        oaepHash: "sha256",
      },
      Buffer.from(message)
    )
    .toString("base64");
}

function decryptMessage(privateKey, ciphertext) {
  try {
    const decrypted = crypto.privateDecrypt(
      {
        key: privateKey,
        padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
        oaepHash: "sha256",
      },
      Buffer.from(ciphertext, "base64")
    );
    return decrypted.toString();
  } catch (err) {
    return null;
  }
}

socket.on("connect", () => {
  console.log("Connected to the server");

  rl.question("Enter your username: ", (input) => {
    username = input.trim();
    generateRSAKeys();

    console.log(`Welcome, ${username} to the chat`);

    socket.emit("registerPublicKey", {
      username,
      publicKey: encodeKey(keyPair.publicKey),
    });

    rl.prompt();

    rl.on("line", (message) => {
      if (!message.trim()) {
        rl.prompt();
        return;
      }
      if (message.match(/^!secret (\w+)$/)) {
        const match = message.match(/^!secret (\w+)$/);
        targetUsername = match[1];
        console.log(`Now secretly chatting with ${targetUsername}`);
      }
      else if (message.match(/^!exit$/)) {
        console.log(`Exited secret chat with ${targetUsername}`);
        targetUsername = "";
      }
      else {
        let messageData = { username, message, isEncrypted: false };
        if (targetUsername && users.has(targetUsername)) {
          const targetKey = users.get(targetUsername);
          const encrypted = encryptMessage(targetKey, message);
          messageData = {
            username,
            message: encrypted,
            target: targetUsername,
            isEncrypted: true,
          };
        }
        socket.emit("message", messageData);
      }
      rl.prompt();
    });
  });
});

socket.on("init", (keys) => {
  keys.forEach(([user, encodedKey]) => users.set(user, decodeKey(encodedKey)));
  console.log(`\nThere are currently ${users.size} users in the chat`);
  rl.prompt();
});

socket.on("newUser", (data) => {
  const { username, publicKey } = data;
  users.set(username, decodeKey(publicKey));
  console.log(`${username} joined the chat`);
  rl.prompt();
});

socket.on("message", (data) => {
  const { username: senderUsername, message: senderMessage, isEncrypted, target } = data;

  if (senderUsername === username) return;

  if (isEncrypted && target === username) {
    const decrypted = decryptMessage(keyPair.privateKey, senderMessage);
    if (decrypted) {
      console.log(`${senderUsername}: ${decrypted}`);
    } else {
      console.log(`${senderUsername} sent you an unreadable message.`);
    }
  }
  else if (isEncrypted) {
    console.log(`${senderUsername}: ${senderMessage}`);
  }
  else {
    console.log(`${senderUsername}: ${senderMessage}`);
  }


  rl.prompt();
});

socket.on("disconnect", () => {
  console.log("Server disconnected, exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});
