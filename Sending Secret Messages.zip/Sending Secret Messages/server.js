const http = require("http");
const socketIo = require("socket.io");

const server = http.createServer();
const io = socketIo(server);

const users = new Map();
const sockets = new Map();

io.on("connection", (socket) => {
  console.log(`Client ${socket.id} connected`);

  socket.emit("init", Array.from(users.entries()));
  socket.on("registerPublicKey", (data) => {
    const { username, publicKey } = data;
    users.set(username, publicKey);
    sockets.set(username, socket.id);
    socket.username = username;
    console.log(`${username} registered with public key.`);


    socket.broadcast.emit("newUser", { username, publicKey });
  });

  socket.on("message", (data) => {
    const { username, message, isEncrypted, target } = data;

    if (isEncrypted && target) {
      for (const [user, pubKey] of users.entries()) {
        if (user === username) continue;
        io.to(sockets.get(user)).emit("message", {
          username,
          message,
          isEncrypted: true,
          target,
        });
      }
    }
    else {
      socket.broadcast.emit("message", { username, message });
    }
  });

  socket.on("disconnect", () => {
    if (socket.username) {
      users.delete(socket.username);
      sockets.delete(socket.username);
      console.log(`${socket.username} disconnected`);
    } else {
      console.log(`Client ${socket.id} disconnected`);
    }
  });
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
